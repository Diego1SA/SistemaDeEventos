public enum CategoriaEvento {
    FESTA, ESPORTE, SHOW, PALESTRA, OUTRO
}
